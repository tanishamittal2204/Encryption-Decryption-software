# Encryption-Decryption--Algorithm
Our Java-based encryption/decryption program uses the Swing GUI library and password protection to ensure authorized access. Users can input a message to be encrypted or decrypted using either the Caesar or Rail Fence cipher. The resulting message is displayed in a text area, and users can choose to save it to a file.

#How to you use it?

Once you open the Main.java file , you can run the programme and hence register as a new user. Once the user is successfully registered, you can login in it and choose the method with which you want to encrypt the text.
